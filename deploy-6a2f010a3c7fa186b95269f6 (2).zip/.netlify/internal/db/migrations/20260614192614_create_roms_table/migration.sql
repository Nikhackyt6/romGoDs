CREATE TABLE "roms" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"platform" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"file_key" text NOT NULL,
	"file_name" text NOT NULL,
	"file_size" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp DEFAULT now()
);
